<?php
class Firebase_Author_chat_Settings_Gneral {
/**
* Holds the values to be used in the fields callbacks
*/
private $options;

private $tab;

/**
* Start up
*/
public function __construct($tab) {
$this->tab = $tab;
$this->options = get_option( "firebase_{$this->tab}_settings_name" );
$this->settings_page_init();
}

/**
* Register and add settings
*/
public function settings_page_init() {
global $Firebase_Author_chat;

$settings_tab_options = array("tab" => "{$this->tab}",
"ref" => &$this,
"sections" => array( 
"custom_settings_section" => array("title" => "Enter your firebase settings below", // Another section
"fields" => array(
	"apikey" => array('title' => __('Api Key', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'apikey', 'name' => 'apikey', 'hints' => __('Firebase Api Key', $Firebase_Author_chat->text_domain)),
	"authdomain" => array('title' => __('Auth Domain', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'authdomain', 'name' => 'authdomain', 'hints' => __('Firebase Auth Domain', $Firebase_Author_chat->text_domain)),
	"databaseurl" => array('title' => __('Database URL', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'databaseurl', 'name' => 'databaseurl', 'hints' => __('Firebase Database URL', $Firebase_Author_chat->text_domain)),
	"projectid" => array('title' => __('Project ID', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'projectid', 'name' => 'projectid', 'hints' => __('Firebase Project ID', $Firebase_Author_chat->text_domain)),
	"storagebucket" => array('title' => __('Storage Bucket', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'storagebucket', 'name' => 'storagebucket', 'hints' => __('Firebase Storage Bucket', $Firebase_Author_chat->text_domain)),
	"messagingsenderid" => array('title' => __('Messaging Sender ID', $Firebase_Author_chat->text_domain), 'type' => 'text', 'id' => 'messagingsenderid', 'name' => 'messagingsenderid', 'hints' => __('Firebase Messaging Sender ID', $Firebase_Author_chat->text_domain)),					
)
)
)
);

$Firebase_Author_chat->admin->settings->settings_field_init(apply_filters("settings_{$this->tab}_tab_options", $settings_tab_options));
}

/**
* Sanitize each setting field as needed
*
* @param array $input Contains all settings fields as array keys
*/
public function firebase_general_settings_sanitize( $input ) {
global $Firebase_Author_chat;
$new_input = array();

$hasError = false;

if( isset( $input['apikey'] ) )
$new_input['apikey'] = sanitize_text_field( $input['apikey'] );

if( isset( $input['authdomain'] ) )
$new_input['authdomain'] = sanitize_text_field( $input['authdomain'] );

if( isset( $input['databaseurl'] ) )
$new_input['databaseurl'] = sanitize_text_field( $input['databaseurl'] );

if( isset( $input['projectid'] ) )
$new_input['projectid'] = sanitize_text_field( $input['projectid'] );

if( isset( $input['storagebucket'] ) )
$new_input['storagebucket'] = sanitize_text_field( $input['storagebucket'] );

if( isset( $input['messagingsenderid'] ) )
$new_input['messagingsenderid'] = sanitize_text_field( $input['messagingsenderid'] );

if(!$hasError) {
add_settings_error(
"firebase_{$this->tab}_settings_name",
esc_attr( "firebase_{$this->tab}_settings_admin_updated" ),
__('Firebase settings updated', $Firebase_Author_chat->text_domain),
'updated'
);
}

return $new_input;
}

/** 
* Print the Section text
*/
public function custom_settings_section_info() {
global $Firebase_Author_chat;
//_e('Enter your firebase settings below', $Firebase_Author_chat->text_domain);
}

}