jQuery(document).ready(function(){

var appconfig = {
  apiKey: wp_object.apikey,
  authDomain: wp_object.authdomain,
  databaseURL: wp_object.databaseurl,
  projectId: wp_object.projectid,
  storageBucket: wp_object.storagebucket,
  messagingSenderId: wp_object.messagingsenderid
};

if(!firebase.apps.length) {
    firebase.initializeApp(appconfig);
}

var messages = firebase.database().ref('posts');

if(wp_object.user_posts) {
jQuery.each(wp_object.user_posts, function( i, val ) {
  var newpost = {
    postname: val,
    authorid: wp_object.user_id,
    authorname: wp_object.fullname,
    authorimage: wp_object.userimage
  };

  firebase.database().ref('posts/' + i).set(newpost);

  });
}

// get all author posts once
messages.once("value", function(snapshot){
  var allposts = snapshot.val();
  jQuery.each(allposts, function(userpostid,userpostdata) {
    jQuery('<li id="authorpost-'+userpostid+'"><a href="javascript:void(0)" class="list-group-item list-group-item-success">'+userpostdata.postname+'</a></li>').appendTo('#authorposts');
  });
});

// Get the data on a post that has changed
messages.on("child_changed", function(snapshot) {
  var changedPost = snapshot.val();

  // update post lists
  var existingPostli = jQuery('#authorpost-' + snapshot.key);  
  if(existingPostli.length > 0) {
    existingPostli.html('');
    existingPostli.append('<a href="javascript:void(0)" class="list-group-item list-group-item-success">'+changedPost.postname+'</a>');
    //console.log(changedPost);
    var postchatheads = changedPost.chatheads;
    if(postchatheads) {
      var uluserchats = jQuery(document.createElement('ul'));
      uluserchats.addClass("chuser");
      uluserchats.css('list-style','none');
      jQuery.each(postchatheads, function( index, value ) {
        //console.log(value);
        if(index) {
            uluserchats.append('<li><a href="javascript:void(0)" class="userchat" data-authoravatar="'+ value.userimage +'" data-authorid="'+ changedPost.authorid +'" data-postid="'+snapshot.key+'" data-userid="'+index+'">' + value.username + '</a></li>');
        }
      });
      existingPostli.append(uluserchats);
    }
  }

  // update chat data
  if(jQuery( "ul.media-list" ).has( "li" ).length) {
    jQuery( "ul.media-list" ).html('');
    var postchathistories = changedPost.userchats;
    if(postchathistories) {
      // get current user chats
      var chatuserid = jQuery( "ul.media-list" ).attr('data-user');
      console.log(chatuserid);
      if(chatuserid) {
        var ref = firebase.database().ref('posts/' + snapshot.key + '/userchats/' + chatuserid + '/messages/');
        ref.on("value", function(chatsnapshot){
        chatsnapshot.forEach(function(messageobj) {
          var message = messageobj.val();          
          if(postchatheads[message.from]) {
            jQuery("ul.media-list").append('<li class="media"><div class="media-body"><div class="media"><a class="pull-left" href="javascript:void(0)"><img class="media-object img-circle " src="' + postchatheads[message.from].userimage + '"></a><div class="media-body">' + message.message + '</div></div></div></li>');            
          }else{
            jQuery("ul.media-list").append('<li class="media"><div class="media-body"><div class="media"><a class="pull-left" href="javascript:void(0)"><img class="media-object img-circle " src="' + changedPost.authorimage + '"></a><div class="media-body">' + message.message + '</div></div></div></li>');
          }
        });
        });
      }
    }
  }
});

/* Rules Backup
{
  "rules" : {
    ".read": true,
      "posts": {
      "$postid": {
        ".read": true,
        ".write": "!data.exists()",
          "chatheads": {
            ".read": true,
            ".write": true,
          },
          "userchats": {
            ".read": true,
            ".write": true,
          }
      }
    }
  }
}
*/
});

jQuery(document).on('click','.userchat',function(){
  var userchatlist = jQuery('.media-list');
  var messagebuttoncontainer = jQuery('#sendmessage');
  userchatlist.html('');
  var chatusername = jQuery(this).text();
  if(jQuery('div#chatusername').length > 0){
    jQuery('div#chatusername').remove();
  }
  jQuery('<div class="col-md-12" id="chatusername"><h2 style="text-transform: capitalize;">'+ chatusername +'</h2></div>').insertBefore('.row.current-chat-area');
  var userid = jQuery(this).data('userid');
  var postid = jQuery(this).data('postid');
  var authorid = jQuery(this).data('authorid');
  var imageurl = jQuery(this).data('authoravatar');
  userchatlist.attr('data-user', userid);

  messagebuttoncontainer.show();
  messagebuttoncontainer.find('span.input-group-btn').html('<button id="sendnow" class="btn btn-default" data-pid="'+ postid +'" data-from="'+ authorid +'" data-to="'+ userid +'" type="button">Send</button>');
  var ref = firebase.database().ref('posts/' + postid + '/userchats/' + userid + '/messages/');
  ref.on("value", function(snapshot){
    snapshot.forEach(function(messageobj) {
      var message = messageobj.val();
      if(message.from==wp_object.user_id) {
        jQuery('<li class="media"><div class="media-body"><div class="media"><a class="pull-left" href="javascript:void(0)"><img class="media-object img-circle " src="' + wp_object.userimage + '"></a><div class="media-body">' + message.message + '</div></div></div></li>').appendTo('.media-list');
      }else{
        jQuery('<li class="media"><div class="media-body"><div class="media"><a class="pull-left" href="javascript:void(0)"><img class="media-object img-circle " src="' + imageurl + '"></a><div class="media-body">' + message.message + '</div></div></div></li>').appendTo('.media-list');
      }          
    });
  });
});


jQuery(document).on('click','#sendnow',function(){
  var from = jQuery(this).data('from');
  var to = jQuery(this).data('to');
  var postid = jQuery(this).data('pid');
  var message = jQuery(this).parent('span.input-group-btn').prev('input#textmessage').val();
  if(message) {
    var chat = {
    to: String(to),
    from: String(from),
    message: message
  };
  firebase.database().ref('posts/' + postid + '/userchats/' + to + '/messages/').push(chat);
    jQuery(this).parent('span.input-group-btn').prev('input#textmessage').val('');
  }
});

jQuery('input#textmessage').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {
    jQuery('#sendnow').click();
    return false;  
  }
});