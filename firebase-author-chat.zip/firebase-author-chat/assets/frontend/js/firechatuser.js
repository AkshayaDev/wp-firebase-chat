jQuery(document).ready(function(){

	var appconfig = {
	  apiKey: wp_user_object.apikey,
	  authDomain: wp_user_object.authdomain,
	  databaseURL: wp_user_object.databaseurl,
	  projectId: wp_user_object.projectid,
	  storageBucket: wp_user_object.storagebucket,
	  messagingSenderId: wp_user_object.messagingsenderid
	};

	if(!firebase.apps.length) {
	firebase.initializeApp(appconfig);
	}

	var messages = firebase.database().ref('posts/' + wp_user_object.postid);	

	//console.log(wp_user_object.postid);

	messages.once("value", function(snapshot){
	console.log('value updated');		
	var postdata = snapshot.val();
	var postchathistories = postdata.userchats;
	var postchatheads = postdata.chatheads;
    if(postchathistories) {
    	var ref = firebase.database().ref('posts/' + wp_user_object.postid + '/userchats/' + wp_user_object.user_id + '/messages/');
        ref.on("value", function(chatsnapshot){
        	var messagecounter = 1;
        	var useravatar = '';
        	jQuery('.chatbox__body').html('');
        chatsnapshot.forEach(function(messageobj) {
          var message = messageobj.val();          
          	if(message) {
	          if(postchatheads[message.from]) {
	           	useravatar = postchatheads[message.from].userimage;            
	          }else{
	          	useravatar = postdata.authorimage;           
	          }
	          if(messagecounter%2==0){
	          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--left"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
	          }else{
	          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--right"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
	          }
	          messagecounter++;
      		}
        });
        });
    }
	});

	messages.on('child_changed', function(data) {
		if(data.key=='userchats') {
			var newuserchats = data.val();
			if(newuserchats) {
				var currentuserchats = newuserchats[wp_user_object.user_id];
				if(currentuserchats) {
					console.log(currentuserchats);
					jQuery('.chatbox__body').html('');
					var messagecounter = 1;
					var useravatar = '';
					jQuery.each(currentuserchats.messages, function( index, message ) {
						if(message.from==wp_user_object.user_id) {
							useravatar = wp_user_object.userimage;            
						}else{
							useravatar = wp_user_object.authorimage;           
						}						
						if(messagecounter%2==0){
				          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--left"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
				          }else{
				          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--right"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
				          }
						messagecounter++;
					});
				}
			}
		}
	});

	messages.on('child_added', function(data) {
		if(data.key=='userchats') {
			var newuserchats = data.val();
			if(newuserchats) {
				var currentuserchats = newuserchats[wp_user_object.user_id];
				if(currentuserchats) {
					console.log(currentuserchats);
					jQuery('.chatbox__body').html('');
					var messagecounter = 1;
					var useravatar = '';
					jQuery.each(currentuserchats.messages, function( index, message ) {
						if(message.from==wp_user_object.user_id) {
							useravatar = wp_user_object.userimage;            
						}else{
							useravatar = wp_user_object.authorimage;           
						}						
						if(messagecounter%2==0){
				          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--left"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
				          }else{
				          	jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--right"><img src="'+ useravatar +'" alt="Picture"><p>'+ message.message +'</p></div>');
				          }
						messagecounter++;
					});
				}
			}
		}
	});

});

(function($) {
    $(document).ready(function() {
        var $chatbox = $('.chatbox'),
            $chatboxTitle = $('.chatbox__title'),
            $chatboxTitleClose = $('.chatbox__title__close'),
            $chatboxCredentials = $('.chatbox__credentials');
        $chatboxTitle.on('click', function() {
            $chatbox.toggleClass('chatbox--tray');
        });
        $chatboxTitleClose.on('click', function(e) {
            e.stopPropagation();
            $chatbox.addClass('chatbox--closed');
        });
        $chatbox.on('transitionend', function() {
            if ($chatbox.hasClass('chatbox--closed')) $chatbox.remove();
        });
        $chatbox.removeClass('chatbox--empty');
        // $chatboxCredentials.on('submit', function(e) {
        //     e.preventDefault();
        //     $chatbox.removeClass('chatbox--empty');
        // });
    });
})(jQuery);

jQuery('textarea.chatbox__message').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {
  	console.log('chat posted');

  	var postedmessage = jQuery(this).val();
  	if(postedmessage) {
  	var chatheads = firebase.database().ref("posts/" + wp_user_object.postid + "/chatheads/");
	chatheads.once('value').then(function(snapshot) {		
		var userchatheads = snapshot.val();
		if(userchatheads) {
			if(userchatheads[wp_user_object.user_id]) {
				// do nothing
			}else{
				var userchathead = {
					username: wp_user_object.username,
					userimage: wp_user_object.userimage
				};
				firebase.database().ref("posts/" + wp_user_object.postid + "/chatheads/" + wp_user_object.user_id).set(userchathead);
			}
		}else{
			var userchathead = {
				username: wp_user_object.username,
				userimage: wp_user_object.userimage
			};
			firebase.database().ref("posts/" + wp_user_object.postid + "/chatheads/" + wp_user_object.user_id).set(userchathead);
		}
	});

	var samplechat = {
		to: jQuery(this).data('to'),
		from: jQuery(this).data('from'),
		message: postedmessage
	};

	firebase.database().ref("posts/" + wp_user_object.postid + "/userchats/" + wp_user_object.user_id + "/messages/").push(samplechat);
    //jQuery('.chatbox__body').append('<div class="chatbox__body__message chatbox__body__message--left"><img src="'+ wp_user_object.userimage +'" alt="Picture"><p>'+ postedmessage +'</p></div>');
    jQuery(this).val('');
	//return false;
  	}
  }
});