<?php
class Firebase_Author_chat_Admin {
  
  public $settings;

	public function __construct() {
		//admin script and style
		add_action('admin_enqueue_scripts', array(&$this, 'enqueue_admin_script'));
		
		add_action('firebase_admin_footer', array(&$this, 'firebase_admin_footer_for_firebase_plugin'));
		
		$this->load_class('settings');
		$this->settings = new Firebase_Author_chat_Settings();
	}
	
	function load_class($class_name = '') {
	  global $Firebase_Author_chat;
		if ('' != $class_name) {
			require_once ($Firebase_Author_chat->plugin_path . '/admin/class-' . esc_attr($Firebase_Author_chat->token) . '-' . esc_attr($class_name) . '.php');
		} // End If Statement
	}// End load_class()
	
	
	function firebase_admin_footer_for_firebase_plugin() {
    global $Firebase_Author_chat;
    ?>
    <div style="clear: both"></div>
    <div id="firebase_admin_footer">
      <?php _e('Developed by', $Firebase_Author_chat->text_domain); ?> <?php _e('Akshaya', $Firebase_Author_chat->text_domain); ?> &copy; <?php echo date('Y');?>
    </div>
    <?php
	}
	
	/**
	 * Admin Scripts
	 */

	public function enqueue_admin_script() {
		global $Firebase_Author_chat;
		$screen = get_current_screen();
		//echo $screen->id;
		
		// Enqueue admin script and stylesheet from here
		if (in_array( $screen->id, array( 'toplevel_page_firebase-settings-admin', 'user-edit' ))) :   
		  $Firebase_Author_chat->library->load_qtip_lib();
		  //$Firebase_Author_chat->library->load_upload_lib();
		  //$Firebase_Author_chat->library->load_colorpicker_lib();
		  //$Firebase_Author_chat->library->load_datepicker_lib();
		  //$Firebase_Author_chat->library->load_select2_lib();
		  wp_enqueue_script('admin_js', $Firebase_Author_chat->plugin_url.'assets/admin/js/admin.js', array('jquery'), $Firebase_Author_chat->version, true);
		  wp_enqueue_style('admin_css',  $Firebase_Author_chat->plugin_url.'assets/admin/css/admin.css', array(), $Firebase_Author_chat->version);
	  endif;
	}
}