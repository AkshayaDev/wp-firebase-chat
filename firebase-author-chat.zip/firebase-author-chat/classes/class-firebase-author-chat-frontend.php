<?php
class Firebase_Author_chat_Frontend {

	public function __construct() {
		//enqueue scripts and styles
		add_action('wp_enqueue_scripts', array(&$this, 'frontend_scripts_styles'));
		add_action('wp_footer', array(&$this,'display_chat_box_func'));
	}

	function frontend_scripts_styles() {
		global $Firebase_Author_chat;
		$frontend_script_path = $Firebase_Author_chat->plugin_url . 'assets/frontend/js/';
		$frontend_style_path = $Firebase_Author_chat->plugin_url . 'assets/frontend/css/';

		if(!is_user_logged_in() && is_page('live-chat')) {
			wp_redirect(site_url());exit;
		}
		
	// Author chat page
	if ( is_user_logged_in() && is_page('live-chat')) {
		wp_enqueue_style('bootstrap-css','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css');
		wp_enqueue_script('slim-js','https://code.jquery.com/jquery-3.2.1.slim.min.js',array('jquery'),'3.2.1', true);
		wp_enqueue_script('popper-js','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js',array('jquery'),'1.12.3', true);
		wp_enqueue_script('bootstrap-js','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js',array('jquery','slim-js','popper-js'),'4.0.0', true);
		
		wp_enqueue_script('firebase-js','https://www.gstatic.com/firebasejs/4.8.0/firebase.js');
		wp_enqueue_script('custom-firechat-js', $frontend_script_path.'firechat.js', array('jquery','firebase-js'), '1.0.0', true);

		$current_user = wp_get_current_user();
	    	$author_query = array('posts_per_page' => '-1','author' => $current_user->ID);
	    	$author_published_posts = array();
	    	$author_posts = new WP_Query($author_query);
	    	while($author_posts->have_posts()) : $author_posts->the_post();
	    		$author_published_posts[get_the_ID()] = get_the_title();
	    	endwhile;
			wp_localize_script( 'custom-firechat-js', 'wp_object', array( 
				'user_posts' => $author_published_posts,
				'user_id' => $current_user->ID,
				'fullname' => $current_user->display_name,
				'username' => $current_user->user_login,
				'userimage' => get_avatar_url($current_user->ID),
				'apikey' => get_firebase_plugin_settings('apikey','general'),
				'authdomain' => get_firebase_plugin_settings('authdomain','general'),
				'databaseurl' => get_firebase_plugin_settings('databaseurl','general'),
				'projectid' => get_firebase_plugin_settings('projectid','general'),
				'storagebucket' => get_firebase_plugin_settings('storagebucket','general'),
				'messagingsenderid' => get_firebase_plugin_settings('messagingsenderid','general'),
			) );

			if(empty($author_published_posts)) {
				wp_redirect(site_url());
	    		exit;
			}
	}

	// User chat details page
	if(is_single() && is_user_logged_in()) {
		global $post;
		$current_user = wp_get_current_user();
		if(!empty($post)) {
			$authorid = $post->post_author;
			$postid = $post->ID;
			if(!empty($authorid)) {

			wp_enqueue_style('bootstrap-css','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css');
			wp_enqueue_script('slim-js','https://code.jquery.com/jquery-3.2.1.slim.min.js',array('jquery'),'3.2.1', true);
			wp_enqueue_script('popper-js','https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js',array('jquery'),'1.12.3', true);
			wp_enqueue_script('bootstrap-js','https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js',array('jquery','slim-js','popper-js'),'4.0.0', true);

			wp_enqueue_style('chatbox-css', $frontend_style_path.'chatbox.css');

			wp_enqueue_script('firebase-js','https://www.gstatic.com/firebasejs/4.8.0/firebase.js');
			wp_enqueue_script('custom-firechat-user-js', $frontend_script_path.'firechatuser.js', array('jquery','firebase-js'), '1.0.0', true);
			wp_localize_script( 'custom-firechat-user-js', 'wp_user_object', array(
				'postid' => $postid,
				'authorid' => $authorid,
				'authorimage' => get_avatar_url( $authorid ),
				'user_id' => $current_user->ID,
				'username' => $current_user->user_login,
				'userimage' => get_avatar_url( $current_user->ID ),
				'apikey' => get_firebase_plugin_settings('apikey','general'),
				'authdomain' => get_firebase_plugin_settings('authdomain','general'),
				'databaseurl' => get_firebase_plugin_settings('databaseurl','general'),
				'projectid' => get_firebase_plugin_settings('projectid','general'),
				'storagebucket' => get_firebase_plugin_settings('storagebucket','general'),
				'messagingsenderid' => get_firebase_plugin_settings('messagingsenderid','general'),
				) );
			}
		}
	}
	}

	function display_chat_box_func() {
		if(is_single() && is_user_logged_in()) {
			global $post;
			$current_user = wp_get_current_user();
			if(!empty($post)) {
				$authorid = $post->post_author;
				$postid = $post->ID;
				if(!empty($authorid)) { ?>
			<div class="chatbox chatbox--tray chatbox--empty">
			<div class="chatbox__title">
			<h5><a href="#">Chat</a></h5>
			<button class="chatbox__title__tray">
			    <span></span>
			</button>
			<button class="chatbox__title__close">
			    <span>
			        <svg viewBox="0 0 12 12" width="12px" height="12px">
			            <line stroke="#FFFFFF" x1="11.75" y1="0.25" x2="0.25" y2="11.75"></line>
			            <line stroke="#FFFFFF" x1="11.75" y1="11.75" x2="0.25" y2="0.25"></line>
			        </svg>
			    </span>
			</button>
			</div>
			<div class="chatbox__body">
			</div>
			<!-- <form class="chatbox__credentials">
			<div class="form-group">
			    <label for="inputName">Name:</label>
			    <input type="text" class="form-control" id="inputName" required>
			</div>
			<div class="form-group">
			    <label for="inputEmail">Email:</label>
			    <input type="email" class="form-control" id="inputEmail" required>
			</div>
			<button type="submit" class="btn btn-success btn-block">Enter Chat</button>
			</form> -->
			<textarea class="chatbox__message" data-to="<?php echo $authorid; ?>" data-from="<?php echo $current_user->ID; ?>" placeholder="Write something interesting"></textarea>
			</div>
			<?php 		}
			}
		}
	}
}
