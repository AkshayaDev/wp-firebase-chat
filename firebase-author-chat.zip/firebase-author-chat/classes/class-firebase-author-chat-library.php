<?php
class Firebase_Author_chat_Library {
  
  public $lib_path;
  
  public $lib_url;
  
  public $php_lib_path;
  
  public $php_lib_url;
  
  public $jquery_lib_path;
  
  public $jquery_lib_url;

	public function __construct() {
	  global $Firebase_Author_chat;
	  
	  $this->lib_path = $Firebase_Author_chat->plugin_path . 'lib/';

    $this->lib_url = $Firebase_Author_chat->plugin_url . 'lib/';
    
    $this->php_lib_path = $this->lib_path . 'php/';
    
    $this->php_lib_url = $this->lib_url . 'php/';
    
    $this->jquery_lib_path = $this->lib_path . 'jquery/';
    
    $this->jquery_lib_url = $this->lib_url . 'jquery/';
	}
	
	/**
	 * PHP WP fields Library
	 */
	public function load_wp_fields() {
	  global $Firebase_Author_chat;
	  if ( ! class_exists( 'FIREBASE_WP_Fields' ) )
	    require_once ($this->php_lib_path . 'class-firebase-author-chat-fields.php');
	  $FIREBASE_WP_Fields = new FIREBASE_WP_Fields(); 
	  return $FIREBASE_WP_Fields;
	}
	
	/**
	 * Jquery qTip library
	 */
	public function load_qtip_lib() {
	  global $Firebase_Author_chat;
	  wp_enqueue_script('qtip_js', $this->jquery_lib_url . 'qtip/qtip.js', array('jquery'), $Firebase_Author_chat->version, true);
		wp_enqueue_style('qtip_css',  $this->jquery_lib_url . 'qtip/qtip.css', array(), $Firebase_Author_chat->version);
	}
	
	/**
	 * WP Media library
	 */
	public function load_upload_lib() {
	  global $Firebase_Author_chat;
	  wp_enqueue_media();
	  wp_enqueue_script('upload_js', $this->jquery_lib_url . 'upload/media-upload.js', array('jquery'), $Firebase_Author_chat->version, true);
	  wp_enqueue_style('upload_css',  $this->jquery_lib_url . 'upload/media-upload.css', array(), $Firebase_Author_chat->version);
	}
	
	/**
	 * WP ColorPicker library
	 */
	public function load_colorpicker_lib() {
	  global $Firebase_Author_chat;
	  wp_enqueue_script( 'wp-color-picker' );
    wp_enqueue_script( 'colorpicker_init', $this->jquery_lib_url . 'colorpicker/colorpicker.js', array( 'jquery', 'wp-color-picker' ), $Firebase_Author_chat->version, true );
    wp_enqueue_style( 'wp-color-picker' );
	}
	
	/**
	 * WP DatePicker library
	 */
	public function load_datepicker_lib() {
	  global $Firebase_Author_chat;
	  wp_enqueue_script('jquery-ui-datepicker');
	  wp_enqueue_style('jquery-style', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');
	}

	/**
	 * WP ColorPicker library
	 */
	public function load_select2_lib() {
		global $Firebase_Author_chat;
		wp_enqueue_script( 'select2_js_init', $this->jquery_lib_url . 'select2/select2.min.js', array( 'jquery'), $Firebase_Author_chat->version, true );
		wp_enqueue_style('select2_css_init',  $this->jquery_lib_url . 'select2/select2.min.css', array(), $Firebase_Author_chat->version);
	}
}