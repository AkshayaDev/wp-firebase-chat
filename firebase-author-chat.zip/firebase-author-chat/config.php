<?php
/**
* Your Plugin's Config File
*
* This file is used to store the plugin-token and text-domain.
* The plugin-token will be used to identify all the class files throughout the plugin.
* The text-domain is used for plugin Internationalization and localization.
*
* @author 		Akshaya
* @category 	Core
* @package 	  your-plugin/config
* @version    1.0.0
**/


define("FIREBASE_AUTHOR_CHAT_TOKEN", "firebase-author-chat");

define("FIREBASE_AUTHOR_CHAT_TEXT_DOMAIN", "firebase_author_chat");

define("FIREBASE_AUTHOR_CHAT_VERSION", "1.0.0");

define("FIREBASE_AUTHOR_CHAT_SERVER_URL", "https://wordpress.org/plugins");