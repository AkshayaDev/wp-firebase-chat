<?php
/*
Plugin Name: Firebase Author Chat
Plugin URI: https://wordpress.org
Description: Chat with author on their details page
Author: Akshaya Swaroop
Version: 1.0.0
Author URI: https://wordpress.org
*/

require_once trailingslashit(dirname(__FILE__)).'config.php';
require_once( trailingslashit(dirname(__FILE__)).'includes/firebase-author-chat-core-functions.php' );
if(!defined('ABSPATH')) exit; // Exit if accessed directly

if(!class_exists('Firebase_Author_chat')) {
	require_once( trailingslashit(dirname(__FILE__)).'classes/class-firebase-author-chat.php' );
	global $Firebase_Author_chat;
	$Firebase_Author_chat = new Firebase_Author_chat( __FILE__ );
	$GLOBALS['Firebase_Author_chat'] = $Firebase_Author_chat;
	
	// Activation Hooks
	register_activation_hook( __FILE__, array('Firebase_Author_chat', 'activate_Firebase_Author_chat') );
	register_activation_hook( __FILE__, 'flush_rewrite_rules' );
	
	// Deactivation Hooks
	register_deactivation_hook( __FILE__, array('Firebase_Author_chat', 'deactivate_Firebase_Author_chat') );
}