<?php
if(!function_exists('input_value')) {
	function input_value($value) {
		if(isset($value) && !empty($value)) {
			return $value;
	  } else {
	  	return null;
	  }
	}
}

if(!function_exists('is_customizable')) {
	function is_customizable() {
		if(is_product()) {
			global $post;
			if(get_post_meta($post->ID, '_customizable', true) == 'yes') return true;
		}
		return false;
	}
}

if(!function_exists('get_firebase_plugin_settings')) {
  function get_firebase_plugin_settings($name = '', $tab = '') {
    if(empty($tab) && empty($name)) return '';
    if(empty($tab)) return get_option($name);
    if(empty($name)) return get_option("firebase_{$tab}_settings_name");
    $settings = get_option("firebase_{$tab}_settings_name");
    if(!isset($settings[$name])) return '';
    return $settings[$name];
  }
}
