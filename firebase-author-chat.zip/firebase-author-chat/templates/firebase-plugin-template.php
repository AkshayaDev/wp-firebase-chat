<?php
/**
 * The template for displaying demo plugin content.
 *
 * Override this template by copying it to yourtheme/firebase-author-chat/firebase-plugin-template.php
 *
 * @author 		Akshaya Swaroop
 * @package 	firebase-author-chat/Templates
 * @version     0.0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
get_header();?>
    <div class="container-fluid">
    <div class="row">
		<div class="col-md-3">
        	 <div class="row chats-row">
                <div class="col-md-12">
                	<ul style="list-style: none;" id="authorposts">
                    </ul>
                </div>
        	 </div>
		</div>
        <div class="col-md-9 current-chat">
            <div class="row current-chat-area" style="background-color: #F6F6F6;">
                <div class="col-md-12">
                      <ul class="media-list"></ul>
                </div>
            </div>
            <div class="row current-chat-footer" id="sendmessage" style="display: none;">
                <div class="panel-footer">
                    <div class="input-group">
                      <input type="text" id="textmessage" class="form-control">
                      <span class="input-group-btn">
                        <button class="btn btn-default" type="button">Send</button>
                      </span>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>
<?php get_footer();